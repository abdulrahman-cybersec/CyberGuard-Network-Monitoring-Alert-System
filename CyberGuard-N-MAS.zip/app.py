#!/usr/bin/env python3
# CyberGuard — Flask dashboard (reads simulated JSON data)
from flask import Flask, render_template, jsonify
import json, os

app = Flask(__name__, template_folder='web/templates', static_folder='web/static')

DATA_FILE = os.path.join(os.path.dirname(__file__), 'simulator', 'latest_events.json')

def read_data():
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {"metrics": {}, "alerts": []}

@app.route('/')
def index():
    data = read_data()
    return render_template('index.html', data=data)

@app.route('/api/data')
def api_data():
    return jsonify(read_data())

if __name__ == '__main__':
    app.run(debug=True)
